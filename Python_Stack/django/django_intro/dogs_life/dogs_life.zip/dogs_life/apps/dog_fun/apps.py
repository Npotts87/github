from django.apps import AppConfig


class DogFunConfig(AppConfig):
    name = 'dog_fun'
